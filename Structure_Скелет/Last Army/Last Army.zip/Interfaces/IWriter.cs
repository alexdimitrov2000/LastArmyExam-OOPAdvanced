﻿public interface IWriter
{
    void AppendLine(string output);
    void WriteLineAll();
}